import 'dart:ui';

class User
{

  int? Id;
  String? Name;
  String? Email;
  String? Password;
  Image? Photo;

}